package com.sunbeaminfo.dao;

import java.util.List;

import com.sunbeaminfo.pojos.Department;
import com.sunbeaminfo.pojos.Employee;

public interface DepartmentDao {
	// add new dept details
	String addNewDepartment(Department dept);
	// delete dept details
		String deleteDepartmentDetails(String deptName);
		//list all depts
		List<Department> getAllDepartments();
}
