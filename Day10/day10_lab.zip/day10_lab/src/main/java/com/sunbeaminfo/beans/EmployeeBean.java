package com.sunbeaminfo.beans;

import java.time.LocalDate;

import com.sunbeaminfo.dao.EmployeeDao;
import com.sunbeaminfo.dao.EmployeeDaoImpl;
import com.sunbeaminfo.pojos.Employee;
import com.sunbeaminfo.pojos.EmploymentType;

/*
 * http://localhost:8080/web_maven_hibernate
 * /process_form.jsp?myDept=3&firstName=a1&lastName=b1
 * &email=a1%40gmail.com&password=2345&
 * empType=PART_TIME&joinDate=2023-07-03
 */
public class EmployeeBean {
	private long myDept;
	private String firstName;
	private String lastName;
	private String email;
	private String password;
	private String empType;
	private String joinDate;
	private double salary;
	// dependency : emp dao
	private EmployeeDao empDao;

	public EmployeeBean() {
		empDao = new EmployeeDaoImpl();
		System.out.println("emp bean created");
	}
	// setters n getters

	public long getMyDept() {
		return myDept;
	}

	public void setMyDept(long myDept) {
		this.myDept = myDept;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmpType() {
		return empType;
	}

	public void setEmpType(String empType) {
		this.empType = empType;
	}

	public String getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(String joinDate) {
		this.joinDate = joinDate;
	}

	public EmployeeDao getEmpDao() {
		return empDao;
	}

	public void setEmpDao(EmployeeDao empDao) {
		this.empDao = empDao;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	// B.L method to validate n add emp
	public String validateAndAddEmployee() {
		// validate join date
		LocalDate date = LocalDate.parse(joinDate);
		LocalDate yearEnd = LocalDate.of(LocalDate.now().getYear(), 12, 31);
		if (date.isBefore(yearEnd))
		{
			// valid date , create transient emp
			Employee newEmp = new Employee(firstName, lastName, email, password, date,
					EmploymentType.valueOf(empType.toUpperCase()), salary);
			// invoke dao's method for persistence
			return empDao.addEmpToDept(newEmp, myDept);

		}
		return "Invalid Join Date !!!!!";
	}

}
