package com.sunbeaminfo.beans;

import java.util.List;

import com.sunbeaminfo.dao.DepartmentDaoImpl;
import com.sunbeaminfo.pojos.Department;

public class DepartmentBean {
//dependency : dept dao
	private DepartmentDaoImpl deptDao;
	public DepartmentBean() {
		deptDao=new DepartmentDaoImpl();
		System.out.println("dept bean created");
	}
	//will you need a getter n setter here ????
	//B.L get list of depts from dao n ret it to JSP
	public List<Department> getAllDepartments() {
		return deptDao.getAllDepartments();
	}
}
