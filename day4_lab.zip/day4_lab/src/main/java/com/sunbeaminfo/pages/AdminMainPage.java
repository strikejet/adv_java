package com.sunbeaminfo.pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sunbeaminfo.dao.CandidateDaoImpl;
import com.sunbeaminfo.pojos.Candidate;
import com.sunbeaminfo.pojos.User;

/**
 * Servlet implementation class AdminMainPage
 */
@WebServlet("/admin_main")
public class AdminMainPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			// get session
			HttpSession session = request.getSession();
			// get user details from session scope
			User admin = (User) session.getAttribute("user_dtls");
			if (admin != null) {
				// print a greeting to admin
				pw.print("<h4>Welcome Admin ! Hello , " + admin.getFirstName() + " </h4>");
				// get candidate dao from session scope
				CandidateDaoImpl dao = (CandidateDaoImpl) session.getAttribute("candidate_dao");
				// invoke methods to get data
				List<Candidate> top2Candidates = dao.getTop2Candidates();
				LinkedHashMap<String, Integer> partywiseVotes = dao.getPartywiseVotes();
				// generate dyn resp
				pw.print("<h3 align='center'>Top 2 Candidates</h3>");
				top2Candidates.forEach(c -> pw.print(c + "<br/>"));
				pw.print("<h3 align='center'>Partywise Votes </h3>");
				partywiseVotes.forEach((k, v) -> pw.print(k + ":" + v + "<br/>"));

			} else
				// if cookies are blocked !
				pw.print("<h4> Session Tracking Failed !!!!! , No Cookies !!! </h4>");
			// invalidate session
			session.invalidate();
			pw.print("<h5><a href='login.html'>Visit Again</a></h5>");
		} catch (Exception e) {
			// re throw the exc to the caller : WC
			throw new ServletException("err in do-get" + getClass(), e);
		}
	}

}
