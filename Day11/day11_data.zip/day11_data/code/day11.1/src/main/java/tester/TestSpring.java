package tester;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import dependent.ATMImpl;

public class TestSpring {

	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext ctx = 
				new ClassPathXmlApplicationContext("bean-config.xml")) {
			System.out.println("SC up n running !");
			//deposit 5000 
			//how to get rdymade bean from SC
			ATMImpl ref1=ctx.getBean("my_atm", ATMImpl.class);
			//B.L
			ref1.deposit(5000);
			ATMImpl ref2=ctx.getBean("my_atm", ATMImpl.class);
			System.out.println(ref1==ref2);//f
		} // JVM : ctx.close --> SC shut down --> SC chks for singleton having destroy
			// method --invokes them -- marks beans for GC --end of life cycle
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
