package com.sunbeaminfo.dao;

import com.sunbeaminfo.pojos.User;
//uses hibernate native (specific) API
import org.hibernate.*;
import static com.sunbeaminfo.utils.HibernateUtils.getFactory;

import java.io.Serializable;

public class UserDaoImpl implements UserDao {

	@Override
	public String registerNewUser(User newUser) {
		String mesg="User registration failed!";
		// 1. get session from SF : openSession
		Session session = getFactory().openSession();
		// 2 Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			//Session API 
			//public Serializable save(Object ref)
			Serializable userId = session.save(newUser);
			tx.commit();
			mesg="User registed with ID "+userId;
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		} finally {
			// close session
			if (session != null)
				session.close();// L1 cache is destroyed n db cn rets to the DB CP
		}
		return mesg;
	}

	@Override
	public User getUserDetailsById(Long userId) {
		User user=null;
		// 1. get session from SF
		Session session=getFactory().openSession();
		//2. begin a tx
		Transaction tx=session.beginTransaction();
		try {
			user=session.get(User.class, userId);
			tx.commit();
		}catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		} finally {
			// close session
			if (session != null)
				session.close();// L1 cache is destroyed n db cn rets to the DB CP
		}
		return user;
	}
	

}
