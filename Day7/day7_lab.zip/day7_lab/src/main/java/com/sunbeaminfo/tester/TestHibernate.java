package com.sunbeaminfo.tester;
import static com.sunbeaminfo.utils.HibernateUtils.getFactory;

import org.hibernate.SessionFactory;

public class TestHibernate {

	public static void main(String[] args) {
		try(SessionFactory sf=getFactory()) //calling a static method --> cls loading --> static init block --> SF creation
		{
			System.out.println("hibernate up n running !!!!");
		}  //JVM : sf.close() => DB CP cleaned up ! 
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
