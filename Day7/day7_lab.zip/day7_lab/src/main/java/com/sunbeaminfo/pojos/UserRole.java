package com.sunbeaminfo.pojos;

public enum UserRole {
	CUSTOMER, ADMIN, MANAGER, BUYER
}
