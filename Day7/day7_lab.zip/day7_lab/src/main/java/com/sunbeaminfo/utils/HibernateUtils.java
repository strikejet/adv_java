package com.sunbeaminfo.utils;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

//to supply singleton , immutable SF
public class HibernateUtils {
	private static SessionFactory factory;
	static {
		factory = new Configuration() // empty def config obj
				.configure() // loads all props n mappings from hibernate.cfg.xml
				.buildSessionFactory();//builds a SF

	}

	public static SessionFactory getFactory() {
		return factory;
	}

}
