package com.sunbeaminfo.dao;

import com.sunbeaminfo.pojos.User;

public interface UserDao {
//add a method for user signup
	String registerNewUser(User newUser);
	//add a method to retrieve user details by id
	User getUserDetailsById(Long userId);
}
