package com.sunbeaminfo.tester;

import static com.sunbeaminfo.utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import com.sunbeaminfo.dao.UserDaoImpl;
import com.sunbeaminfo.pojos.User;
import com.sunbeaminfo.pojos.UserRole;

public class GetUserDetails {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory(); // calling a static method --> cls loading --> static init block --> SF
												// creation
				Scanner sc = new Scanner(System.in);

		) {
			// user dao instance
			UserDaoImpl userDao = new UserDaoImpl();
			System.out.println("Enter user id ");
			// invoke dao's method			
			System.out.println(userDao.getUserDetailsById(sc.nextLong()));

		} // JVM : sf.close() => DB CP cleaned up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
