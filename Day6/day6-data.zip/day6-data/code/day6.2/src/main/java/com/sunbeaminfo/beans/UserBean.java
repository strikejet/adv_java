package com.sunbeaminfo.beans;

import java.sql.SQLException;

import com.sunbeaminfo.dao.UserDaoImpl;
import com.sunbeaminfo.pojos.User;

public class UserBean {
	// clnt 's req params
	private String email;
	private String password;
	// dao
	private UserDaoImpl userDao;
	// user details : pojo
	private User userDetails;

	public UserBean() throws SQLException {
		userDao = new UserDaoImpl();
		System.out.println("user bean created !");
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserDaoImpl getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDaoImpl userDao) {
		this.userDao = userDao;
	}

	public User getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(User userDetails) {
		this.userDetails = userDetails;
	}

	// B.L method for authentication + authorization
	public String validateUser() throws SQLException {
		System.out.println("in validate user " + email + " " + password);
		// invoke dao's method
		userDetails = userDao.autheticateUser(email, password);
		if (userDetails == null) {
			// invalid login
			return "login";
		}
		// => valid login , role based authorization
		if (userDetails.getRole().equals("admin"))
			return "admin_main";
		// voter : role
		if (userDetails.isStatus())
			return "logout";
		return "candidate_list";

	}
}
